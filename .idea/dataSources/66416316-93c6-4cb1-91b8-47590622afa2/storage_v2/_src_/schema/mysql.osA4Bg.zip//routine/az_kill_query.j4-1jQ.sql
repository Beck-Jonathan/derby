create
    definer = azure_superuser@localhost procedure az_kill_query(IN thread bigint) reads sql data
BEGIN    DECLARE ownerUser varchar(32);    DECLARE ownerHost varchar(64);    SELECT USER, HOST INTO ownerUser, ownerHost    FROM information_schema.processlist    WHERE ID = thread;    IF ownerUser = "azure_superuser" AND ownerHost LIKE "localhost" THEN       SIGNAL SQLSTATE '45000' 	  SET MESSAGE_TEXT = 'You are not allowed to kill the query whose owner is azure_superuser';    ELSE       KILL QUERY thread;    END IF; END;

