create
    definer = gzggtzuamz@`%` procedure sp_update_user_password(IN p_email varchar(255), IN p_password varchar(255))
BEGIN
    UPDATE user
    SET password = p_password
    WHERE email = p_email;
END;

