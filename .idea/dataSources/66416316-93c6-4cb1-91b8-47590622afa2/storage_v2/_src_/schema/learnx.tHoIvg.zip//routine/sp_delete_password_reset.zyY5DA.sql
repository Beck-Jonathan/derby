create
    definer = gzggtzuamz@`%` procedure sp_delete_password_reset(IN p_id int)
BEGIN
    DELETE FROM password_reset WHERE id = p_id;
END;

