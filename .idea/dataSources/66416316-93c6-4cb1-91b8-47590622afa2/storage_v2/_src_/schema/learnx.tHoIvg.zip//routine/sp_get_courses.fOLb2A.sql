create
    definer = gzggtzuamz@`%` procedure sp_get_courses(IN p_limit int, IN p_offset int, IN p_category_id varchar(255),
                                                      IN p_skill_level varchar(255))
BEGIN
    SELECT c.id, c.name, c.description, c.level, c.picture, u.first_name, u.last_name, g.id AS category_id, g.name AS category_name
    FROM user AS u JOIN course AS c JOIN course_category AS g
    WHERE u.id = c.teacher_id
      AND g.id = c.category_id
      AND (
        CASE
            WHEN p_category_id <> ''
                THEN p_category_id LIKE CONCAT('%', c.category_id , '%')
            ELSE TRUE
            END
        )
      AND (
        CASE
            WHEN p_skill_level <> ''
                THEN c.level = p_skill_level
            ELSE TRUE
            END
        )
    LIMIT p_limit OFFSET p_offset;
END;

