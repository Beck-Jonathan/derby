create
    definer = gzggtzuamz@`%` procedure sp_get_2fa_code(IN p_email varchar(255))
BEGIN
    SELECT t.code, t.method, t.created_at
    FROM user AS u JOIN 2fa_code AS t
    WHERE u.id = t.user_id
      AND u.email = p_email;
END;

