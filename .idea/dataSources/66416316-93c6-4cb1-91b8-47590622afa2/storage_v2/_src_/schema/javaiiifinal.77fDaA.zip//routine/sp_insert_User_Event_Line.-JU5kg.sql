create
    definer = gzggtzuamz@`%` procedure sp_insert_User_Event_Line(IN User_ID_param int, IN Event_ID_param int)
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    INSERT INTO  User_Event_Line
    values
        (User_ID
        ,Event_ID
        )
    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

