create
    definer = gzggtzuamz@`%` procedure sp_insert_User(IN User_ID_param int, IN User_Name_param varchar(100),
                                                      IN User_PW_param varchar(100), IN Status_param varchar(100))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    INSERT INTO  User
    values
        (User_ID
        ,User_Name
        ,User_PW
        ,Status
        )
    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

