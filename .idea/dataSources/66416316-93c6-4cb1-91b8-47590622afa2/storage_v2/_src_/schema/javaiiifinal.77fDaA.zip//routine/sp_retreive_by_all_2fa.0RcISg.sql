create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_2fa()
begin
    SELECT

        2fa_ID
         ,User_ID
         ,2fa_code
    FROM 2fa
    ;
END;

