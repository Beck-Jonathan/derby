create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Team(IN Team_ID int)
Begin
    select
        Team_ID
         ,League_ID
         ,Team_Name
         ,Team_Primary_Color
         ,Team_City
         ,Team_State

    FROM Team
    where Team_ID=Team_ID
    ; END;

