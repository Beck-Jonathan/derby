create
    definer = gzggtzuamz@`%` procedure sp_insert_League(IN League_ID_param int, IN League_Level_param varchar(100))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    INSERT INTO  League
    values
        (League_ID
        ,League_Level
        )
    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

