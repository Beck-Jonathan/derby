create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Team()
begin
    SELECT

        Team_ID
         ,League_ID
         ,Team_Name
         ,Team_Primary_Color
         ,Team_City
         ,Team_State
    FROM Team
    ;
END;

