create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_User_Team_Line(IN User_ID int, IN Team_ID int)
Begin
    select
        User_ID
         ,Team_ID
         ,Date_assgined

    FROM User_Team_Line
    where User_ID=User_ID
      AND Team_ID=Team_ID
    ; END;

