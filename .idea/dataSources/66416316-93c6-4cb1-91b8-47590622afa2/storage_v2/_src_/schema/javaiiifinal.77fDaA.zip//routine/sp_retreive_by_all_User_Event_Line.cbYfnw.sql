create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_User_Event_Line()
begin
    SELECT

        User_ID
         ,Event_ID
    FROM User_Event_Line
    ;
END;

