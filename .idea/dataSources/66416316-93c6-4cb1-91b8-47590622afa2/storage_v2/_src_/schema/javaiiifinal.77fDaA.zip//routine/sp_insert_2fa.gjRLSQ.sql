create
    definer = gzggtzuamz@`%` procedure sp_insert_2fa(IN `2fa_ID_param` int, IN User_ID_param int,
                                                     IN `2fa_code_param` varchar(6))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    INSERT INTO  2fa
    values
        (2fa_ID
        ,User_ID
        ,2fa_code
        )
    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

