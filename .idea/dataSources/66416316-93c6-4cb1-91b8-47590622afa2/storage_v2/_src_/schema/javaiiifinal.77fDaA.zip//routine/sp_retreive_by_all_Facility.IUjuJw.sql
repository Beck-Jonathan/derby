create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Facility()
begin
    SELECT

        Facility_ID
         ,Name
         ,Addresss
         ,City
         ,State
         ,Zip
    FROM Facility
    ;
END;

