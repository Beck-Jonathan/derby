create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_League()
begin
    SELECT

        League_ID
         ,League_Level
    FROM League
    ;
END;

