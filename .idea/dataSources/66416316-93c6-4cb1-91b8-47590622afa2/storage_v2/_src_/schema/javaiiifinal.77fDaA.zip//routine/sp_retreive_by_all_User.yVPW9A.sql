create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_User()
begin
    SELECT

        User_ID
         ,User_Name
         ,User_PW
         ,Status
    FROM User
    ;
END;

