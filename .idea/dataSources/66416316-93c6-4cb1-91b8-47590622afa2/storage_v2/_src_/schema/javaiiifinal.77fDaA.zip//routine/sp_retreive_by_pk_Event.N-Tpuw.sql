create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Event(IN Event_ID int)
Begin
    select
        Event_ID
         ,Facility_ID
         ,Date
         ,Type

    FROM Event
    where Event_ID=Event_ID
    ; END;

