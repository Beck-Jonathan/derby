create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Facility(IN Facility_ID int)
Begin
    select
        Facility_ID
         ,Name
         ,Addresss
         ,City
         ,State
         ,Zip

    FROM Facility
    where Facility_ID=Facility_ID
    ; END;

