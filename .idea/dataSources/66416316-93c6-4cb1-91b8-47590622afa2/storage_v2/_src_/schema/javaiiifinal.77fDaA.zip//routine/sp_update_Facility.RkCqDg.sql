create
    definer = gzggtzuamz@`%` procedure sp_update_Facility(IN oldFacility_ID int, IN newFacility_ID int,
                                                          IN oldName varchar(100), IN newName varchar(100),
                                                          IN oldAddresss varchar(100), IN newAddresss varchar(100),
                                                          IN oldCity varchar(100), IN newCity varchar(100),
                                                          IN oldState varchar(100), IN newState varchar(100),
                                                          IN oldZip varchar(5), IN newZip varchar(5))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    UPDATE Facility
    set Name = newName
      ,Addresss = newAddresss
      ,City = newCity
      ,State = newState
      ,Zip = newZip
    WHERE Facility_ID= oldFacility_ID

    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

