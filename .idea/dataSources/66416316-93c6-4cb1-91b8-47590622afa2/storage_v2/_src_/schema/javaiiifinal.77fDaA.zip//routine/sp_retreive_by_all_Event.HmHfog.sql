create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Event()
begin
    SELECT

        Event_ID
         ,Facility_ID
         ,Date
         ,Type
    FROM Event
    ;
END;

