create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_2fa(IN `2fa_ID` int)
Begin
    select
        2fa_ID
         ,User_ID
         ,2fa_code

    FROM 2fa
    where 2fa_ID=2fa_ID
    ; END;

