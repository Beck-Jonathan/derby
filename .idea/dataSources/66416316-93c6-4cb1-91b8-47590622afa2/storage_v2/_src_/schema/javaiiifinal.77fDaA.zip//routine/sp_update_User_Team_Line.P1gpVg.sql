create
    definer = gzggtzuamz@`%` procedure sp_update_User_Team_Line(IN oldUser_ID int, IN newUser_ID int, IN oldTeam_ID int,
                                                                IN newTeam_ID int, IN oldDate_assgined datetime,
                                                                IN newDate_assgined datetime)
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    UPDATE User_Team_Line
    set Date_assgined = newDate_assgined
    WHERE User_ID= oldUser_ID
      AND Team_ID= oldTeam_ID

    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

