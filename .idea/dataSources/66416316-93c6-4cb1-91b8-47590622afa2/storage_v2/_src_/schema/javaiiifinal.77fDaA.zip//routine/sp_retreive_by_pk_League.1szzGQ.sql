create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_League(IN League_ID int)
Begin
    select
        League_ID
         ,League_Level

    FROM League
    where League_ID=League_ID
    ; END;

