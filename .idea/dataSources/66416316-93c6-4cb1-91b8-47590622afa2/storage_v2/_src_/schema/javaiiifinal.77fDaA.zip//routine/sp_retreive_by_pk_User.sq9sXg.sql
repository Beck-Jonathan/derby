create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_User(IN User_ID int)
Begin
    select
        User_ID
         ,User_Name
         ,User_PW
         ,Status

    FROM User
    where User_ID=User_ID
    ; END;

