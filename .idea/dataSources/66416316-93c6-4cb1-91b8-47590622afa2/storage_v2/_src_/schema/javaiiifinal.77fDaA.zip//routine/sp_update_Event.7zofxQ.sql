create
    definer = gzggtzuamz@`%` procedure sp_update_Event(IN oldEvent_ID int, IN newEvent_ID int, IN oldFacility_ID int,
                                                       IN newFacility_ID int, IN oldDate datetime, IN newDate datetime,
                                                       IN oldType varchar(100), IN newType varchar(100))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    UPDATE Event
    set Facility_ID = newFacility_ID
      ,Date = newDate
      ,Type = newType
    WHERE Event_ID= oldEvent_ID

    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

