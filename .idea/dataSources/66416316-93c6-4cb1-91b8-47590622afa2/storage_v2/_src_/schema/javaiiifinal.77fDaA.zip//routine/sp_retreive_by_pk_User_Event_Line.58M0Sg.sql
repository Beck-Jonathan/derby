create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_User_Event_Line(IN User_ID int, IN Event_ID int)
Begin
    select
        User_ID
         ,Event_ID

    FROM User_Event_Line
    where User_ID=User_ID
      AND Event_ID=Event_ID
    ; END;

