create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Role(IN Role_ID varchar(50))
Begin
    select
        Role_ID
         ,Description

    FROM Role
    where Role_ID=Role_ID
    ; END;

