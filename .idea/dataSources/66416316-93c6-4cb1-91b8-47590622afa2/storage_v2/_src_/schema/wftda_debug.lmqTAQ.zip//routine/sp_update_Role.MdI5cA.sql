create
    definer = gzggtzuamz@`%` procedure sp_update_Role(IN oldRole_ID varchar(50), IN newRole_ID varchar(50),
                                                      IN oldDescription varchar(250), IN newDescription varchar(250))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    UPDATE Role
    set Description = newDescription
    WHERE Role_ID=oldRole_ID

    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

