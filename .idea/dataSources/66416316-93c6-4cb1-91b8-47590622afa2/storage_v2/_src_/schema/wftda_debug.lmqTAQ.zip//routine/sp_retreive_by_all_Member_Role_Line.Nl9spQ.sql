create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Member_Role_Line()
begin
    SELECT

        League_Member_Id
         ,Role_ID
    FROM Member_Role_Line
    ;
END;

