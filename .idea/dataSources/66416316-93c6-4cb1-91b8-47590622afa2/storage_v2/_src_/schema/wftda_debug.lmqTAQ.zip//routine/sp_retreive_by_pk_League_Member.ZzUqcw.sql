create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_League_Member(IN League_Member_Id int)
Begin
    select
        League_Member_Id
         ,Team_ID
         ,City
         ,State
         ,Zip

    FROM League_Member
    where League_Member_Id=League_Member_Id
    ; END;

