create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Team()
begin
    SELECT

        Team_ID
         ,City
         ,State
         ,Zip
    FROM Team
    ;
END;

