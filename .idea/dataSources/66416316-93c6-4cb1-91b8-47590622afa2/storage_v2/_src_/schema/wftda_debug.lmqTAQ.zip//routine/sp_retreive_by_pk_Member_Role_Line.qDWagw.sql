create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Member_Role_Line(IN League_Member_Id int, IN Role_ID varchar(50))
Begin
    select
        League_Member_Id
         ,Role_ID

    FROM Member_Role_Line
    where League_Member_Id=League_Member_Id
      AND Role_ID=Role_ID
    ; END;

