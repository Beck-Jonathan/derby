create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Facility()
begin
    SELECT

        Facility_ID
         ,City
         ,Sttate
         ,Zip
         ,Facility_Name
    FROM Facility
    ;
END;

