create
    definer = gzggtzuamz@`%` procedure sp_insert_Facility(IN Facility_ID_param int, IN City_param varchar(50),
                                                          IN Sttate_param varchar(50), IN Zip_param varchar(5),
                                                          IN Facility_Name_param varchar(250))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    INSERT INTO  Facility
    values
        (Facility_ID
        ,City
        ,Sttate
        ,Zip
        ,Facility_Name
        )
    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

