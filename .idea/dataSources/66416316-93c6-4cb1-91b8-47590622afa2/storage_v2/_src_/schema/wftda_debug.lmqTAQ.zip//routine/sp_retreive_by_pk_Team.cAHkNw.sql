create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Team(IN Team_ID varchar(50))
Begin
    select
        Team_ID
         ,City
         ,State
         ,Zip

    FROM Team
    where Team_ID=Team_ID
    ; END;

