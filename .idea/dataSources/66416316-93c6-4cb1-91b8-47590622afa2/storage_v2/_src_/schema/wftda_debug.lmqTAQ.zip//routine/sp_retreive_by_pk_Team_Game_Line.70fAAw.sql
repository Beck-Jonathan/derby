create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Team_Game_Line(IN Team_ID varchar(50), IN Game_ID int)
Begin
    select
        Team_ID
         ,Game_ID
         ,Points

    FROM Team_Game_Line
    where Team_ID=Team_ID
      AND Game_ID=Game_ID
    ; END;

