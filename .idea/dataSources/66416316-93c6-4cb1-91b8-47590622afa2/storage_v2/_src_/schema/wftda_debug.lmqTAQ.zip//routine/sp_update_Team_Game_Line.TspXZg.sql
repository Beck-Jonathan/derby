create
    definer = gzggtzuamz@`%` procedure sp_update_Team_Game_Line(IN oldTeam_ID varchar(50), IN newTeam_ID varchar(50),
                                                                IN oldGame_ID int, IN newGame_ID int, IN oldPoints int,
                                                                IN newPoints int)
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    UPDATE Team_Game_Line
    set Points = newPoints
    WHERE Team_ID=oldTeam_ID
      AND Game_ID=oldGame_ID

    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

