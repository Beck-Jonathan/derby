create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Role()
begin
    SELECT

        Role_ID
         ,Description
    FROM Role
    ;
END;

