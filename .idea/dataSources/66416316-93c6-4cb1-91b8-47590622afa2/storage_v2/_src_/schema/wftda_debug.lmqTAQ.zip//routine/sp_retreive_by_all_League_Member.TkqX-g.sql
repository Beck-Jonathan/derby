create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_League_Member()
begin
    SELECT

        League_Member_Id
         ,Team_ID
         ,City
         ,State
         ,Zip
    FROM League_Member
    ;
END;

