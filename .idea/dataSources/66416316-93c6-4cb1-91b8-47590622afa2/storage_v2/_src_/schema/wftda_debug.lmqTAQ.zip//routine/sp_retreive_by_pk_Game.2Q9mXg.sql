create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Game(IN Game_ID int)
Begin
    select
        Game_ID
         ,Facility_Id
         ,Attenance
         ,Date

    FROM Game
    where Game_ID=Game_ID
    ; END;

