create
    definer = gzggtzuamz@`%` procedure sp_insert_League_Member(IN League_Member_Id_param int,
                                                               IN Team_ID_param varchar(50), IN City_param varchar(50),
                                                               IN State_param varchar(50), IN Zip_param varchar(5))
begin
    declare sql_error TINYINT DEFAULT FALSE;
    declare update_count tinyint default 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        SET sql_error = true;
    START TRANSACTION;
    INSERT INTO  League_Member
    values
        (League_Member_Id
        ,Team_ID
        ,City
        ,State
        ,Zip
        )
    ; if sql_error = FALSE then
        SET update_count = row_count();
        COMMIT;
    ELSE
        SET update_count = 0;
        ROLLBACK;
    END IF;
    select update_count as 'update count'
    ; END;

