create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Team_Game_Line()
begin
    SELECT

        Team_ID
         ,Game_ID
         ,Points
    FROM Team_Game_Line
    ;
END;

