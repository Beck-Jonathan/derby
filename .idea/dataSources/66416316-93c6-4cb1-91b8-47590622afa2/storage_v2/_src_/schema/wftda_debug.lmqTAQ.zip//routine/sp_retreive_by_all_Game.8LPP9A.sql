create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Game()
begin
    SELECT

        Game_ID
         ,Facility_Id
         ,Attenance
         ,Date
    FROM Game
    ;
END;

