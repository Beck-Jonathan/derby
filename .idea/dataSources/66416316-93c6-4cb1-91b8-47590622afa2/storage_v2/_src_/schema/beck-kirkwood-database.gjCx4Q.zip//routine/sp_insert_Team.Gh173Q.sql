create
    definer = gzggtzuamz@`%` procedure sp_insert_Team(IN Team_ID_param varchar(50), IN League_param varchar(50),
                                                      IN Stadium_Name_param varchar(50),
                                                      IN Stadium_Location_param varchar(50))
begin 
declare sql_error TINYINT DEFAULT FALSE;
declare update_count tinyint default 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
SET sql_error = true;
START TRANSACTION;
INSERT INTO  Team
 values 
(Team_ID
,League
,Stadium_Name
,Stadium_Location
)
 ; if sql_error = FALSE then 
 SET update_count = row_count(); 
 COMMIT;
 ELSE
 SET update_count = 0;
 ROLLBACK;
 END IF;
 select update_count as 'update count'
 ; END;

