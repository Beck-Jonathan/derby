create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_all_Team()
begin 
 SELECT 

Team_ID
,League
,Stadium_Name
,Stadium_Location
 FROM Team
 ;
 END;

