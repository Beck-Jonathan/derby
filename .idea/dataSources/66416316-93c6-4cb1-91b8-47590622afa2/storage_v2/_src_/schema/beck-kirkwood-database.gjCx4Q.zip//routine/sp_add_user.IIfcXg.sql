create
    definer = gzggtzuamz@`%` procedure sp_add_user(IN p_email varchar(255), IN p_password varchar(255))
BEGIN
    INSERT INTO user (email, password)
    VALUES (p_email,p_password);
END;

