create
    definer = gzggtzuamz@`%` procedure sp_retreive_by_pk_Team()
Begin 
 select 
Team_ID 
,League 
,Stadium_Name 
,Stadium_Location 

 FROM Team
 ; END;

